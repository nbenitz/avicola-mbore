export type BoardHandle = {
  exportPNG: (name?: string) => void;
  exportPDF: (name?: string) => void;
};
